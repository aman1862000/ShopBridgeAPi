﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Shopbridge_base.Filters
{
    public class HandlleExceptionFilter : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var cc = context.Exception;
            context.Result = new OkObjectResult(new { statusCode = 500, errMessage = "Internal Server Error",errDetail=cc.Message });
        }
    }
}
