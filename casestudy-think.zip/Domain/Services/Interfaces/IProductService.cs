﻿using Shopbridge_base.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Services.Interfaces
{
    public interface IProductService
    {
        public Task<List<Product>> GetProduct();
        public Task<Product> GetProduct(int productId);
        public Task<Product> AddProduct(Product product);
        public Task<bool> DeleteProduct(int ProductId);
        public Task<Product> UpdateProduct(int id,Product product);

    }
}
