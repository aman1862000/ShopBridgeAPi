﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Data;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Services
{
    public class ProductService : IProductService
    {
        private readonly ILogger<ProductService> logger;
        private readonly Shopbridge_Context context;
        public ProductService(Shopbridge_Context context)
        {
            this.context = context;
        }

        public async Task<Product> AddProduct(Product product)
        {
            var newProd = await context.Product.AddAsync(product);
            await context.SaveChangesAsync();
            return product;
        }

        public async Task<bool> DeleteProduct(int ProductId)
        {
            var prod = await context.Product.FindAsync(ProductId);
            if (prod != null)
            {
                context.Remove(prod);
                await context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<List<Product>> GetProduct()
        {
            return await context.Product.ToListAsync();
        }

        public async Task<Product> GetProduct(int productId)
        {
            return await context.Product.Where(p => p.ProductId.Equals(productId)).FirstOrDefaultAsync();
        }

        public async Task<Product> UpdateProduct(int id,Product product)
        {
            var prod = await context.Product.FindAsync(id); 
            if(prod != null)
            {
                prod.Name = product.Name;
                prod.Description = product.Description;
                prod.Price = product.Price;
                await context.SaveChangesAsync();
                return prod;
            }
            return prod;
        }
    }
}
