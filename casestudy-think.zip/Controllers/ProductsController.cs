﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Data;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;
using Shopbridge_base.Filters;

namespace Shopbridge_base.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [HandlleExceptionFilter]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        public ProductsController(IProductService _productService)
        {
            this.productService = _productService;
        }

       
        [HttpGet]   
        public async Task<ActionResult<IEnumerable<Product>>> GetProduct(int pageIndex = 1,int pageSize = 5)
        {
            var productList = await productService.GetProduct();
            int skip = (pageIndex - 1) * pageSize, total = productList.Count;
            int totalPage = (int)Math.Ceiling(total / (double)pageSize);

            return Ok(new {pageIndex= pageIndex, pageSize= pageSize,total=total,totalPage=totalPage,Data= productList.Skip(skip).Take(pageSize) });
        }

        
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            Product product = await productService.GetProduct(id);
            if(product != null)
            {
                return Ok(product);
            }
            return BadRequest();
        }

       
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            var prod = await productService.UpdateProduct(id, product);
            if (prod != null)
            {
                return Ok(new { Message = "Product Updated successfully",Data = product });
            }
            return BadRequest();
        }

        
        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct(Product product)
        {
            var prod = await productService.AddProduct(product);
            return Ok(prod);
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var isProd = await productService.DeleteProduct(id);
            if (isProd)
            {
                return Ok(new { Message = "Product Deleted successfully" });
            }
            return BadRequest();
        }

    }
}
